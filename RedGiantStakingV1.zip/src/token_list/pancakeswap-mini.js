export default {
    name: "PancakeSwap Mini",
    timestamp: "2022-05-28T04:52:37.543Z",
    version: {
        major: 1,
        minor: 0,
        patch: 1
    },
    logoURI: "https://pancakeswap.finance/logo.png",
    tokens: [
        {
            name: "PancakeSwap Token",
            symbol: "CAKE",
            address: "0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82.png"
        },
        {
            name: "1INCH Token",
            symbol: "1INCH",
            address: "0x111111111117dC0aa78b770fA6A738034120C302",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x111111111117dC0aa78b770fA6A738034120C302/logo.png"
        },
        {
            name: "Aave Token",
            symbol: "AAVE",
            address: "0xfb6115445Bff7b52FeB98650C87f44907E58f802",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0xfb6115445Bff7b52FeB98650C87f44907E58f802/logo.png"
        },
        {
            name: "Alchemy Token",
            symbol: "ACH",
            address: "0xBc7d6B50616989655AfD682fb42743507003056D",
            chainId: 56,
            decimals: 8,
            logoURI: "https://tokens.pancakeswap.finance/images/0xBc7d6B50616989655AfD682fb42743507003056D.png"
        },
        {
            name: "Cardano Token",
            symbol: "ADA",
            address: "0x3EE2200Efb3400fAbB9AacF31297cBdD1d435D47",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x3EE2200Efb3400fAbB9AacF31297cBdD1d435D47.png"
        },
        {
            name: "AdEx Network",
            symbol: "ADX",
            address: "0x6bfF4Fb161347ad7de4A625AE5aa3A1CA7077819",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x6bfF4Fb161347ad7de4A625AE5aa3A1CA7077819.png"
        },
        {
            name: "My Neigbor Alice",
            symbol: "ALICE",
            address: "0xAC51066d7bEC65Dc4589368da368b212745d63E8",
            chainId: 56,
            decimals: 6,
            logoURI: "https://tokens.pancakeswap.finance/images/0xAC51066d7bEC65Dc4589368da368b212745d63E8.png"
        },
        {
            name: "Alpaca",
            symbol: "ALPACA",
            address: "0x8F0528cE5eF7B51152A59745bEfDD91D97091d2F",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x8F0528cE5eF7B51152A59745bEfDD91D97091d2F.png"
        },
        {
            name: "AlphaToken",
            symbol: "ALPHA",
            address: "0xa1faa113cbE53436Df28FF0aEe54275c13B40975",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xa1faa113cbE53436Df28FF0aEe54275c13B40975.png"
        },
        {
            name: "ALPINE Fan Token",
            symbol: "ALPINE",
            address: "0x287880Ea252b52b63Cc5f40a2d3E5A44aa665a76",
            chainId: 56,
            decimals: 8,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x287880Ea252b52b63Cc5f40a2d3E5A44aa665a76/logo.png"
        },
        {
            name: "Ankr",
            symbol: "ANKR",
            address: "0xf307910A4c7bbc79691fD374889b36d8531B08e3",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xf307910A4c7bbc79691fD374889b36d8531B08e3.png"
        },
        {
            name: "ARPA",
            symbol: "ARPA",
            address: "0x6F769E65c14Ebd1f68817F5f1DcDb61Cfa2D6f7e",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x6F769E65c14Ebd1f68817F5f1DcDb61Cfa2D6f7e.png"
        },
        {
            name: "Automata",
            symbol: "ATA",
            address: "0xA2120b9e674d3fC3875f415A7DF52e382F141225",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xA2120b9e674d3fC3875f415A7DF52e382F141225.png"
        },
        {
            name: "Cosmos Token",
            symbol: "ATOM",
            address: "0x0Eb3a705fc54725037CC9e008bDede697f62F335",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x0Eb3a705fc54725037CC9e008bDede697f62F335.png"
        },
        {
            name: "AUTOv2",
            symbol: "AUTO",
            address: "0xa184088a740c695E156F91f5cC086a06bb78b827",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xa184088a740c695E156F91f5cC086a06bb78b827.png"
        },
        {
            name: "Travala.com Token",
            symbol: "AVA",
            address: "0x13616F44Ba82D63c8C0DC3Ff843D36a8ec1c05a9",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x13616F44Ba82D63c8C0DC3Ff843D36a8ec1c05a9/logo.png"
        },
        {
            name: "Avalanche",
            symbol: "AVAX",
            address: "0x1CE0c2827e2eF14D5C4f29a091d735A204794041",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x1CE0c2827e2eF14D5C4f29a091d735A204794041/logo.png"
        },
        {
            name: "Axie Infinity Shard",
            symbol: "AXS",
            address: "0x715D400F88C167884bbCc41C5FeA407ed4D2f8A0",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x715D400F88C167884bbCc41C5FeA407ed4D2f8A0.png"
        },
        {
            name: "Bakery Token",
            symbol: "BAKE",
            address: "0xE02dF9e3e622DeBdD69fb838bB799E3F168902c5",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xE02dF9e3e622DeBdD69fb838bB799E3F168902c5.png"
        },
        {
            name: "BAND Protocol Token",
            symbol: "BAND",
            address: "0xAD6cAEb32CD2c308980a548bD0Bc5AA4306c6c18",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xAD6cAEb32CD2c308980a548bD0Bc5AA4306c6c18.png"
        },
        {
            name: "Basic Attention Token",
            symbol: "BAT",
            address: "0x101d82428437127bF1608F699CD651e6Abf9766E",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x101d82428437127bF1608F699CD651e6Abf9766E.png"
        },
        {
            name: "Bitcoin Cash Token",
            symbol: "BCH",
            address: "0x8fF795a6F4D97E7887C79beA79aba5cc76444aDf",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x8fF795a6F4D97E7887C79beA79aba5cc76444aDf.png"
        },
        {
            name: "Bella Protocol",
            symbol: "BEL",
            address: "0x8443f091997f06a61670B735ED92734F5628692F",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x8443f091997f06a61670B735ED92734F5628692F.png"
        },
        {
            name: "Beta Finance",
            symbol: "BETA",
            address: "0xBe1a001FE942f96Eea22bA08783140B9Dcc09D28",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xBe1a001FE942f96Eea22bA08783140B9Dcc09D28.png"
        },
        {
            name: "Beacon ETH",
            symbol: "BETH",
            address: "0x250632378E573c6Be1AC2f97Fcdf00515d0Aa91B",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x250632378E573c6Be1AC2f97Fcdf00515d0Aa91B.png"
        },
        {
            name: "Beefy.finance",
            symbol: "BIFI",
            address: "0xCa3F508B8e4Dd382eE878A314789373D80A5190A",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xCa3F508B8e4Dd382eE878A314789373D80A5190A.png"
        },
        {
            name: "BinaryX",
            symbol: "BNX",
            address: "0x8C851d1a123Ff703BD1f9dabe631b69902Df5f97",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x8C851d1a123Ff703BD1f9dabe631b69902Df5f97/logo.png"
        },
        {
            name: "Binance Pegged Bitcoin",
            symbol: "BTCB",
            address: "0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c.png"
        },
        {
            name: "Standard BTC Hashrate Token",
            symbol: "BTCST",
            address: "0x78650B139471520656b9E7aA7A5e9276814a38e9",
            chainId: 56,
            decimals: 17,
            logoURI: "https://tokens.pancakeswap.finance/images/0x78650B139471520656b9E7aA7A5e9276814a38e9.png"
        },
        {
            name: "Bittorrent",
            symbol: "BTT",
            address: "0x352Cb5E19b12FC216548a2677bD0fce83BaE434B",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x352Cb5E19b12FC216548a2677bD0fce83BaE434B.png"
        },
        {
            name: "Burger Swap",
            symbol: "BURGER",
            address: "0xAe9269f27437f0fcBC232d39Ec814844a51d6b8f",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xAe9269f27437f0fcBC232d39Ec814844a51d6b8f.png"
        },
        {
            name: "Binance Pegged BUSD",
            symbol: "BUSD",
            address: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56.png"
        },
        {
            name: "Coin98",
            symbol: "C98",
            address: "0xaEC945e04baF28b135Fa7c640f624f8D90F1C3a6",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xaEC945e04baF28b135Fa7c640f624f8D90F1C3a6.png"
        },
        {
            name: "CelerToken",
            symbol: "CELR",
            address: "0x1f9f6a696C6Fd109cD3956F45dC709d2b3902163",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x1f9f6a696C6Fd109cD3956F45dC709d2b3902163/logo.png"
        },
        {
            name: "Tranchess",
            symbol: "CHESS",
            address: "0x20de22029ab63cf9A7Cf5fEB2b737Ca1eE4c82A6",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x20de22029ab63cf9A7Cf5fEB2b737Ca1eE4c82A6.png"
        },
        {
            name: "Chromia",
            symbol: "CHR",
            address: "0xf9CeC8d50f6c8ad3Fb6dcCEC577e05aA32B224FE",
            chainId: 56,
            decimals: 6,
            logoURI: "https://tokens.pancakeswap.finance/images/0xf9CeC8d50f6c8ad3Fb6dcCEC577e05aA32B224FE.png"
        },
        {
            name: "Clover",
            symbol: "CLV",
            address: "0x09E889BB4D5b474f561db0491C38702F367A4e4d",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x09E889BB4D5b474f561db0491C38702F367A4e4d/logo.png"
        },
        {
            name: "Compound Finance",
            symbol: "COMP",
            address: "0x52CE071Bd9b1C4B00A0b92D298c512478CaD67e8",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x52CE071Bd9b1C4B00A0b92D298c512478CaD67e8.png"
        },
        {
            name: "COTI Token",
            symbol: "COTI",
            address: "0xAdBAF88B39D37Dc68775eD1541F1bf83A5A45feB",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0xAdBAF88B39D37Dc68775eD1541F1bf83A5A45feB/logo.png"
        },
        {
            name: "Cream",
            symbol: "CREAM",
            address: "0xd4CB328A82bDf5f03eB737f37Fa6B370aef3e888",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xd4CB328A82bDf5f03eB737f37Fa6B370aef3e888.png"
        },
        {
            name: "CertiK Token",
            symbol: "CTK",
            address: "0xA8c2B8eec3d368C0253ad3dae65a5F2BBB89c929",
            chainId: 56,
            decimals: 6,
            logoURI: "https://tokens.pancakeswap.finance/images/0xA8c2B8eec3d368C0253ad3dae65a5F2BBB89c929.png"
        },
        {
            name: "Cartesi Token",
            symbol: "CTSI",
            address: "0x8dA443F84fEA710266C8eB6bC34B71702d033EF2",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x8dA443F84fEA710266C8eB6bC34B71702d033EF2/logo.png"
        },
        {
            name: "Binance Pegged DAI",
            symbol: "DAI",
            address: "0x1AF3F329e8BE154074D8769D1FFa4eE058B1DBc3",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x1AF3F329e8BE154074D8769D1FFa4eE058B1DBc3.png"
        },
        {
            name: "Mines of Dalarnia",
            symbol: "DAR",
            address: "0x23CE9e926048273eF83be0A3A8Ba9Cb6D45cd978",
            chainId: 56,
            decimals: 6,
            logoURI: "https://tokens.pancakeswap.finance/images/0x23CE9e926048273eF83be0A3A8Ba9Cb6D45cd978.png"
        },
        {
            name: "Dego.Finance",
            symbol: "DEGO",
            address: "0x3FdA9383A84C05eC8f7630Fe10AdF1fAC13241CC",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x3FdA9383A84C05eC8f7630Fe10AdF1fAC13241CC.png"
        },
        {
            name: "DeXe",
            symbol: "DEXE",
            address: "0x039cB485212f996A9DBb85A9a75d898F94d38dA6",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x039cB485212f996A9DBb85A9a75d898F94d38dA6.png"
        },
        {
            name: "dForce",
            symbol: "DF",
            address: "0x4A9A2b2b04549C3927dd2c9668A5eF3fCA473623",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x4A9A2b2b04549C3927dd2c9668A5eF3fCA473623/logo.png"
        },
        {
            name: "Dodo",
            symbol: "DODO",
            address: "0x67ee3Cb086F8a16f34beE3ca72FAD36F7Db929e2",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x67ee3Cb086F8a16f34beE3ca72FAD36F7Db929e2.png"
        },
        {
            name: "Dogecoin",
            symbol: "DOGE",
            address: "0xbA2aE424d960c26247Dd6c32edC70B295c744C43",
            chainId: 56,
            decimals: 8,
            logoURI: "https://tokens.pancakeswap.finance/images/0xbA2aE424d960c26247Dd6c32edC70B295c744C43.png"
        },
        {
            name: "Polkadot Token",
            symbol: "DOT",
            address: "0x7083609fCE4d1d8Dc0C979AAb8c869Ea2C873402",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x7083609fCE4d1d8Dc0C979AAb8c869Ea2C873402.png"
        },
        {
            name: "Dusk",
            symbol: "DUSK",
            address: "0xB2BD0749DBE21f623d9BABa856D3B0f0e1BFEc9C",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xB2BD0749DBE21f623d9BABa856D3B0f0e1BFEc9C.png"
        },
        {
            name: "Elrond",
            symbol: "EGLD",
            address: "0xbF7c81FFF98BbE61B40Ed186e4AfD6DDd01337fe",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xbF7c81FFF98BbE61B40Ed186e4AfD6DDd01337fe.png"
        },
        {
            name: "ELF Token",
            symbol: "ELF",
            address: "0xa3f020a5C92e15be13CAF0Ee5C95cF79585EeCC9",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0xa3f020a5C92e15be13CAF0Ee5C95cF79585EeCC9/logo.png"
        },
        {
            name: "EOS Token",
            symbol: "EOS",
            address: "0x56b6fB708fC5732DEC1Afc8D8556423A2EDcCbD6",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x56b6fB708fC5732DEC1Afc8D8556423A2EDcCbD6.png"
        },
        {
            name: "Ellipsis",
            symbol: "EPS",
            address: "0xA7f552078dcC247C2684336020c03648500C6d9F",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xA7f552078dcC247C2684336020c03648500C6d9F.png"
        },
        {
            name: "Ethereum Classic",
            symbol: "ETC",
            address: "0x3d6545b08693daE087E957cb1180ee38B9e3c25E",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x3d6545b08693daE087E957cb1180ee38B9e3c25E/logo.png"
        },
        {
            name: "Binance Pegged ETH",
            symbol: "ETH",
            address: "0x2170Ed0880ac9A755fd29B2688956BD959F933F8",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x2170Ed0880ac9A755fd29B2688956BD959F933F8.png"
        },
        {
            name: "Easy V2",
            symbol: "EZ",
            address: "0x5512014efa6Cd57764Fa743756F7a6Ce3358cC83",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x5512014efa6Cd57764Fa743756F7a6Ce3358cC83.png"
        },
        {
            name: "Fetch",
            symbol: "FET",
            address: "0x031b41e504677879370e9DBcF937283A8691Fa7f",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x031b41e504677879370e9DBcF937283A8691Fa7f/logo.png"
        },
        {
            name: "Filecoin",
            symbol: "FIL",
            address: "0x0D8Ce2A99Bb6e3B7Db580eD848240e4a0F9aE153",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x0D8Ce2A99Bb6e3B7Db580eD848240e4a0F9aE153.png"
        },
        {
            name: "Firo",
            symbol: "FIRO",
            address: "0xd5d0322b6bAb6a762C79f8c81A0B674778E13aeD",
            chainId: 56,
            decimals: 8,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0xd5d0322b6bAb6a762C79f8c81A0B674778E13aeD/logo.png"
        },
        {
            name: "Flux",
            symbol: "FLUX",
            address: "0xaFF9084f2374585879e8B434C399E29E80ccE635",
            chainId: 56,
            decimals: 8,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0xaFF9084f2374585879e8B434C399E29E80ccE635/logo.png"
        },
        {
            name: "ForTube",
            symbol: "FOR",
            address: "0x658A109C5900BC6d2357c87549B651670E5b0539",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x658A109C5900BC6d2357c87549B651670E5b0539.png"
        },
        {
            name: "Frontier Token",
            symbol: "FRONT",
            address: "0x928e55daB735aa8260AF3cEDadA18B5f70C72f1b",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x928e55daB735aa8260AF3cEDadA18B5f70C72f1b.png"
        },
        {
            name: "Fantom",
            symbol: "FTM",
            address: "0xAD29AbB318791D579433D831ed122aFeAf29dcfe",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0xAD29AbB318791D579433D831ed122aFeAf29dcfe/logo.png"
        },
        {
            name: "pTokens GALA",
            symbol: "GALA",
            address: "0x7dDEE176F665cD201F93eEDE625770E2fD911990",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x7dDEE176F665cD201F93eEDE625770E2fD911990/logo.png"
        },
        {
            name: "Highstreet Token",
            symbol: "HIGH",
            address: "0x5f4Bde007Dc06b867f86EBFE4802e34A1fFEEd63",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x5f4Bde007Dc06b867f86EBFE4802e34A1fFEEd63.png"
        },
        {
            name: "Injective Protocol",
            symbol: "INJ",
            address: "0xa2B726B1145A4773F68593CF171187d8EBe4d495",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xa2B726B1145A4773F68593CF171187d8EBe4d495.png"
        },
        {
            name: "MIOTAC",
            symbol: "IOTA",
            address: "0xd944f1D1e9d5f9Bb90b62f9D45e447D989580782",
            chainId: 56,
            decimals: 6,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0xd944f1D1e9d5f9Bb90b62f9D45e447D989580782/logo.png"
        },
        {
            name: "IoTeX",
            symbol: "IOTX",
            address: "0x9678E42ceBEb63F23197D726B29b1CB20d0064E5",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x9678E42ceBEb63F23197D726B29b1CB20d0064E5.png"
        },
        {
            name: "Kyber Network Crystal",
            symbol: "KNC",
            address: "0xfe56d5892BDffC7BF58f2E84BE1b2C32D21C308b",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0xfe56d5892BDffC7BF58f2E84BE1b2C32D21C308b/logo.png"
        },
        {
            name: "FC Lazio Fan Token",
            symbol: "LAZIO",
            address: "0x77d547256A2cD95F32F67aE0313E450Ac200648d",
            chainId: 56,
            decimals: 8,
            logoURI: "https://tokens.pancakeswap.finance/images/0x77d547256A2cD95F32F67aE0313E450Ac200648d.png"
        },
        {
            name: "Linear Finance",
            symbol: "LINA",
            address: "0x762539b45A1dCcE3D36d080F74d1AED37844b878",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x762539b45A1dCcE3D36d080F74d1AED37844b878.png"
        },
        {
            name: "ChainLink Token",
            symbol: "LINK",
            address: "0xF8A0BF9cF54Bb92F17374d9e9A321E6a111a51bD",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xF8A0BF9cF54Bb92F17374d9e9A321E6a111a51bD.png"
        },
        {
            name: "Loom Token",
            symbol: "LOOM",
            address: "0xE6Ce27025F13f5213bBc560dC275e292965a392F",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0xE6Ce27025F13f5213bBc560dC275e292965a392F/logo.png"
        },
        {
            name: "Litecoin Token",
            symbol: "LTC",
            address: "0x4338665CBB7B2485A8855A139b75D5e34AB0DB94",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x4338665CBB7B2485A8855A139b75D5e34AB0DB94.png"
        },
        {
            name: "LTO Network",
            symbol: "LTO",
            address: "0x857B222Fc79e1cBBf8Ca5f78CB133d1b7CF34BBd",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x857B222Fc79e1cBBf8Ca5f78CB133d1b7CF34BBd.png"
        },
        {
            name: "Mask Network",
            symbol: "MASK",
            address: "0x2eD9a5C8C13b93955103B9a7C167B67Ef4d568a3",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x2eD9a5C8C13b93955103B9a7C167B67Ef4d568a3.png"
        },
        {
            name: "Matic Token",
            symbol: "MATIC",
            address: "0xCC42724C6683B7E57334c4E856f4c9965ED682bD",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0xCC42724C6683B7E57334c4E856f4c9965ED682bD/logo.png"
        },
        {
            name: "Mobox",
            symbol: "MBOX",
            address: "0x3203c9E46cA618C8C1cE5dC67e7e9D75f5da2377",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x3203c9E46cA618C8C1cE5dC67e7e9D75f5da2377.png"
        },
        {
            name: "MDX Token",
            symbol: "MDX",
            address: "0x9C65AB58d8d978DB963e63f2bfB7121627e3a739",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x9C65AB58d8d978DB963e63f2bfB7121627e3a739/logo.png"
        },
        {
            name: "Mirror Finance",
            symbol: "MIR",
            address: "0x5B6DcF557E2aBE2323c48445E8CC948910d8c2c9",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x5B6DcF557E2aBE2323c48445E8CC948910d8c2c9.png"
        },
        {
            name: "Maker",
            symbol: "MKR",
            address: "0x5f0Da599BB2ccCfcf6Fdfd7D81743B6020864350",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x5f0Da599BB2ccCfcf6Fdfd7D81743B6020864350/logo.png"
        },
        {
            name: "NEAR Protocol",
            symbol: "NEAR",
            address: "0x1Fa4a73a3F0133f0025378af00236f3aBDEE5D63",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x1Fa4a73a3F0133f0025378af00236f3aBDEE5D63/logo.png"
        },
        {
            name: "Nuls",
            symbol: "NULS",
            address: "0x8CD6e29d3686d24d3C2018CEe54621eA0f89313B",
            chainId: 56,
            decimals: 8,
            logoURI: "https://tokens.pancakeswap.finance/images/0x8CD6e29d3686d24d3C2018CEe54621eA0f89313B.png"
        },
        {
            name: "MANTRA DAO",
            symbol: "OM",
            address: "0xF78D2e7936F5Fe18308A3B2951A93b6c4a41F5e2",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0xF78D2e7936F5Fe18308A3B2951A93b6c4a41F5e2/logo.png"
        },
        {
            name: "Ontology Token",
            symbol: "ONT",
            address: "0xFd7B3A77848f1C2D67E05E54d78d174a0C850335",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xFd7B3A77848f1C2D67E05E54d78d174a0C850335.png"
        },
        {
            name: "Perlin X",
            symbol: "PERL",
            address: "0x0F9E4D49f25de22c2202aF916B681FBB3790497B",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x0F9E4D49f25de22c2202aF916B681FBB3790497B.png"
        },
        {
            name: "Phoenix Global",
            symbol: "PHB",
            address: "0x0409633A72D846fc5BBe2f98D88564D35987904D",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x0409633A72D846fc5BBe2f98D88564D35987904D/logo.png"
        },
        {
            name: "PNT",
            symbol: "PNT",
            address: "0xdaacB0Ab6Fb34d24E8a67BfA14BF4D95D4C7aF92",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xdaacB0Ab6Fb34d24E8a67BfA14BF4D95D4C7aF92.png"
        },
        {
            name: "PolkastarterToken",
            symbol: "POLS",
            address: "0x7e624FA0E1c4AbFD309cC15719b7E2580887f570",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x7e624FA0E1c4AbFD309cC15719b7E2580887f570/logo.png"
        },
        {
            name: "FC Porto Fan Token",
            symbol: "PORTO",
            address: "0x49f2145d6366099e13B10FbF80646C0F377eE7f6",
            chainId: 56,
            decimals: 8,
            logoURI: "https://tokens.pancakeswap.finance/images/0x49f2145d6366099e13B10FbF80646C0F377eE7f6.png"
        },
        {
            name: "Prometeus",
            symbol: "PROM",
            address: "0xaF53d56ff99f1322515E54FdDE93FF8b3b7DAFd5",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xaF53d56ff99f1322515E54FdDE93FF8b3b7DAFd5.png"
        },
        {
            name: "Prosper",
            symbol: "PROS",
            address: "0xEd8c8Aa8299C10f067496BB66f8cC7Fb338A3405",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xEd8c8Aa8299C10f067496BB66f8cC7Fb338A3405.png"
        },
        {
            name: "Ramp DEFI",
            symbol: "RAMP",
            address: "0x8519EA49c997f50cefFa444d240fB655e89248Aa",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x8519EA49c997f50cefFa444d240fB655e89248Aa.png"
        },
        {
            name: "renBTC",
            symbol: "renBTC",
            address: "0xfCe146bF3146100cfe5dB4129cf6C82b0eF4Ad8c",
            chainId: 56,
            decimals: 8,
            logoURI: "https://tokens.pancakeswap.finance/images/0xfCe146bF3146100cfe5dB4129cf6C82b0eF4Ad8c.png"
        },
        {
            name: "FC Santos Fan Token",
            symbol: "SANTOS",
            address: "0xA64455a4553C9034236734FadDAddbb64aCE4Cc7",
            chainId: 56,
            decimals: 8,
            logoURI: "https://tokens.pancakeswap.finance/images/0xA64455a4553C9034236734FadDAddbb64aCE4Cc7.png"
        },
        {
            name: "SafePal Token",
            symbol: "SFP",
            address: "0xD41FDb03Ba84762dD66a0af1a6C8540FF1ba5dfb",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xD41FDb03Ba84762dD66a0af1a6C8540FF1ba5dfb.png"
        },
        {
            name: "SHIBA INU",
            symbol: "SHIB",
            address: "0x2859e4544C4bB03966803b044A93563Bd2D0DD4D",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x2859e4544C4bB03966803b044A93563Bd2D0DD4D/logo.png"
        },
        {
            name: "Synthetix Network Token",
            symbol: "SNX",
            address: "0x9Ac983826058b8a9C7Aa1C9171441191232E8404",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x9Ac983826058b8a9C7Aa1C9171441191232E8404/logo.png"
        },
        {
            name: "SPARTAN PROTOCOL TOKEN",
            symbol: "SPARTA",
            address: "0x3910db0600eA925F63C36DdB1351aB6E2c6eb102",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x3910db0600eA925F63C36DdB1351aB6E2c6eb102.png"
        },
        {
            name: "SUPER-ERC20",
            symbol: "SUPER",
            address: "0x51BA0b044d96C3aBfcA52B64D733603CCC4F0d4D",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x51BA0b044d96C3aBfcA52B64D733603CCC4F0d4D/logo.png"
        },
        {
            name: "Sushi",
            symbol: "SUSHI",
            address: "0x947950BcC74888a40Ffa2593C5798F11Fc9124C4",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x947950BcC74888a40Ffa2593C5798F11Fc9124C4.png"
        },
        {
            name: "Swipe",
            symbol: "SXP",
            address: "0x47BEAd2563dCBf3bF2c9407fEa4dC236fAbA485A",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x47BEAd2563dCBf3bF2c9407fEa4dC236fAbA485A.png"
        },
        {
            name: "Token Club",
            symbol: "TCT",
            address: "0xCA0a9Df6a8cAD800046C1DDc5755810718b65C44",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0xCA0a9Df6a8cAD800046C1DDc5755810718b65C44/logo.png"
        },
        {
            name: "TokoCrypto",
            symbol: "TKO",
            address: "0x9f589e3eabe42ebC94A44727b3f3531C0c877809",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x9f589e3eabe42ebC94A44727b3f3531C0c877809.png"
        },
        {
            name: "Alien Worlds",
            symbol: "TLM",
            address: "0x2222227E22102Fe3322098e4CBfE18cFebD57c95",
            chainId: 56,
            decimals: 4,
            logoURI: "https://tokens.pancakeswap.finance/images/0x2222227E22102Fe3322098e4CBfE18cFebD57c95.png"
        },
        {
            name: "TornadoCash",
            symbol: "TORN",
            address: "0x1bA8D3C4c219B124d351F603060663BD1bcd9bbF",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x1bA8D3C4c219B124d351F603060663BD1bcd9bbF/logo.png"
        },
        {
            name: "Tron",
            symbol: "TRX",
            address: "0x85EAC5Ac2F758618dFa09bDbe0cf174e7d574D5B",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x85EAC5Ac2F758618dFa09bDbe0cf174e7d574D5B.png"
        },
        {
            name: "True USD",
            symbol: "TUSD",
            address: "0x14016E85a25aeb13065688cAFB43044C2ef86784",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x14016E85a25aeb13065688cAFB43044C2ef86784.png"
        },
        {
            name: "Trust Wallet",
            symbol: "TWT",
            address: "0x4B0F1812e5Df2A09796481Ff14017e6005508003",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x4B0F1812e5Df2A09796481Ff14017e6005508003.png"
        },
        {
            name: "UniLend Finance Token",
            symbol: "UFT",
            address: "0x2645d5f59D952ef2317C8e0AaA5A61c392cCd44d",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x2645d5f59D952ef2317C8e0AaA5A61c392cCd44d/logo.png"
        },
        {
            name: "Unifi Token",
            symbol: "UNFI",
            address: "0x728C5baC3C3e370E372Fc4671f9ef6916b814d8B",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x728C5baC3C3e370E372Fc4671f9ef6916b814d8B.png"
        },
        {
            name: "Uniswap",
            symbol: "UNI",
            address: "0xBf5140A22578168FD562DCcF235E5D43A02ce9B1",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xBf5140A22578168FD562DCcF235E5D43A02ce9B1.png"
        },
        {
            name: "Binance Pegged USD Coin",
            symbol: "USDC",
            address: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d.png"
        },
        {
            name: "Binance Pegged USDT",
            symbol: "USDT",
            address: "0x55d398326f99059fF775485246999027B3197955",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x55d398326f99059fF775485246999027B3197955.png"
        },
        {
            name: "UST Token",
            symbol: "UST",
            address: "0x23396cF899Ca06c4472205fC903bDB4de249D6fC",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x23396cF899Ca06c4472205fC903bDB4de249D6fC.png"
        },
        {
            name: "VIDT Datalink",
            symbol: "VIDT",
            address: "0x3f515f0a8e93F2E2f891ceeB3Db4e62e202d7110",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x3f515f0a8e93F2E2f891ceeB3Db4e62e202d7110/logo.png"
        },
        {
            name: "Vite",
            symbol: "VITE",
            address: "0x2794DAD4077602eD25A88d03781528D1637898B4",
            chainId: 56,
            decimals: 18,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x2794DAD4077602eD25A88d03781528D1637898B4/logo.png"
        },
        {
            name: "WBNB Token",
            symbol: "WBNB",
            address: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c.png"
        },
        {
            name: "WINk",
            symbol: "WIN",
            address: "0xaeF0d72a118ce24feE3cD1d43d383897D05B4e99",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xaeF0d72a118ce24feE3cD1d43d383897D05B4e99.png"
        },
        {
            name: "Wootrade",
            symbol: "WOO",
            address: "0x4691937a7508860F876c9c0a2a617E7d9E945D4B",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x4691937a7508860F876c9c0a2a617E7d9E945D4B.png"
        },
        {
            name: "wazirx token",
            symbol: "WRX",
            address: "0x8e17ed70334C87eCE574C9d537BC153d8609e2a3",
            chainId: 56,
            decimals: 8,
            logoURI: "https://assets-cdn.trustwallet.com/blockchains/smartchain/assets/0x8e17ed70334C87eCE574C9d537BC153d8609e2a3/logo.png"
        },
        {
            name: "XRP Token",
            symbol: "XRP",
            address: "0x1D2F0da169ceB9fC7B3144628dB156f3F6c60dBE",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x1D2F0da169ceB9fC7B3144628dB156f3F6c60dBE.png"
        },
        {
            name: "Tezos Token",
            symbol: "XTZ",
            address: "0x16939ef78684453bfDFb47825F8a5F714f12623a",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x16939ef78684453bfDFb47825F8a5F714f12623a.png"
        },
        {
            name: "Venus Token",
            symbol: "XVS",
            address: "0xcF6BB5389c92Bdda8a3747Ddb454cB7a64626C63",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0xcF6BB5389c92Bdda8a3747Ddb454cB7a64626C63.png"
        },
        {
            name: "yearn.finance",
            symbol: "YFI",
            address: "0x88f1A5ae2A3BF98AEAF342D26B30a79438c9142e",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x88f1A5ae2A3BF98AEAF342D26B30a79438c9142e.png"
        },
        {
            name: "YFII.finance Token",
            symbol: "YFII",
            address: "0x7F70642d88cf1C4a3a7abb072B53B929b653edA5",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x7F70642d88cf1C4a3a7abb072B53B929b653edA5.png"
        },
        {
            name: "Zcash Token",
            symbol: "ZEC",
            address: "0x1Ba42e5193dfA8B03D15dd1B86a3113bbBEF8Eeb",
            chainId: 56,
            decimals: 18,
            logoURI: "https://tokens.pancakeswap.finance/images/0x1Ba42e5193dfA8B03D15dd1B86a3113bbBEF8Eeb.png"
        },
        {
            name: "Zilliqa",
            symbol: "ZIL",
            address: "0xb86AbCb37C3A4B64f74f59301AFF131a1BEcC787",
            chainId: 56,
            decimals: 12,
            logoURI: "https://tokens.pancakeswap.finance/images/0xb86AbCb37C3A4B64f74f59301AFF131a1BEcC787.png"
        }
    ]
}