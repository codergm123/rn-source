const Web3 = require("web3");
const express = require("express");
const axios = require('axios');
const BN = require('bn.js');
const Fs = require('fs/promises');
const { stringify } = require('csv-stringify');
const { parse } = require('path');
const Moralis = require("moralis").default;
const { EvmChain } = require("@moralisweb3/common-evm-utils");

const app = express();

var provider = 'https://mainnet.infura.io/v3/8c1f6af0bba24e5287b4433e59a6fa63';
var web3Provider = new Web3.providers.HttpProvider(provider);
var web3 = new Web3(web3Provider);

const AddrUniswapRouter = "0x7a250d5630b4cf539739df2c5dacb4c659f2488d";
const AddrUniswapFactory = '0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f';
const AddrHiloTokenContract = '0xbb9FD9Fa4863C03c574007fF3370787B9cE65ff6';
const AddrPredictionMarketContract = '0x196247c168F1B94D969CF24F044C1FBa9d394B48';
const AddrLPToken = '0x659e36b0700D9addB259EbA18fA88173656ef054';
const LPTokenSymbol = 'Uniswap V2: USDC-HILO';

const ABILPToken = [{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount0","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"Burn","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount0","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1","type":"uint256"}],"name":"Mint","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount0In","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1In","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount0Out","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1Out","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"Swap","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint112","name":"reserve0","type":"uint112"},{"indexed":false,"internalType":"uint112","name":"reserve1","type":"uint112"}],"name":"Sync","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"constant":true,"inputs":[],"name":"DOMAIN_SEPARATOR","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"MINIMUM_LIQUIDITY","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"PERMIT_TYPEHASH","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"to","type":"address"}],"name":"burn","outputs":[{"internalType":"uint256","name":"amount0","type":"uint256"},{"internalType":"uint256","name":"amount1","type":"uint256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"factory","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"getReserves","outputs":[{"internalType":"uint112","name":"_reserve0","type":"uint112"},{"internalType":"uint112","name":"_reserve1","type":"uint112"},{"internalType":"uint32","name":"_blockTimestampLast","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"_token0","type":"address"},{"internalType":"address","name":"_token1","type":"address"}],"name":"initialize","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"kLast","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"to","type":"address"}],"name":"mint","outputs":[{"internalType":"uint256","name":"liquidity","type":"uint256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"nonces","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"permit","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"price0CumulativeLast","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"price1CumulativeLast","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"to","type":"address"}],"name":"skim","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"uint256","name":"amount0Out","type":"uint256"},{"internalType":"uint256","name":"amount1Out","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"swap","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[],"name":"sync","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"token0","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"token1","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"}];

const DecimalHilo = 18;

const MoralisAPIKey = 'rydCaW0KZV9iA4LAErpAtJR3gsQILYFAJhEkesN9bgsKiGwhdoeFO6dhuUdDHYk8';

let txData = [];

let columns = {
	txHash: "txHash",
	action: "action",
	address: "address",
	quantity: "quantity",
	usd: "usd"
};

let resultTemplate = {
	txHash: "txHash",
	action: "action",
	address: "address",
	quantity: "quantity",
	usd: "usd"
};

const getTXData = async () => {
	let index = 0;
	let cursor;
	try {
        await Moralis.start({
            apiKey: MoralisAPIKey,
            // ...and any other configuration
        });

        const address = AddrHiloTokenContract;
        const chain = EvmChain.ETHEREUM;
        let response;
        
        do {
            response = await Moralis.EvmApi.token.getWalletTokenTransfers({
                address,
                chain,
                limit: 100,
                cursor
            });
            
            cursor = response.toJSON().cursor;

            console.log(cursor);

            const history = response.toJSON().result;

            await Fs.writeFile(`./txData/relatedTxData${index}.json`, JSON.stringify({history, cursor}));

        	index++;
        } while (cursor != null)

    } catch (e) {
    	console.log(cursor);
        console.log(e);
    }

	await Fs.writeFile('./txData/totalFileCount.json', JSON.stringify(index));
};

const setFullTXData = async () => {
	const jsonTX = await Fs.readFile('./txData/totalFileCount.json');
	const dataTX = JSON.parse(jsonTX);
	const num = dataTX.index;

	for (let i = 0; i < num; i++) {
		const json = await Fs.readFile(`./txData/relatedTxData${i}.json`);
		const data = await JSON.parse(json);
		const history = data.history;

		for(let item of history) {
			txData.push(item);
		}
	}

	await Fs.writeFile('./relatedTxData.json', JSON.stringify(txData));
}

const getFullTXData = async () => {
	const json = await Fs.readFile('./txData/relatedTxData.json');
	const data = await JSON.parse(json);
	txData = data.txData;
	console.log(txData.length);
}

const getTokenPrice = async () => {
	
}

const getTransferData = async () => {
    const wallet_address = AddrLPToken.toLowerCase();
    const hashMap = [];
    const tradingData = [];

    try {
        await Moralis.start({
            apiKey: MoralisAPIKey,
        });

        const address = AddrLPToken;
        const chain = EvmChain.ETHEREUM;
        let cursor;
        let response;
        let index = 0;

       do {
            response = await Moralis.EvmApi.token.getWalletTokenTransfers({
                address,
                chain,
                limit: 100,
                cursor
            });
            cursor = response.toJSON().cursor;
            const history = response.toJSON().result;

            let lastHash = '';
            let lastTradingData;
            let txdatas;

            for (let i = 0; i < history.length; i++) {

                const transactionHash = history[i].transaction_hash;
				const chain = EvmChain.ETHEREUM;
				
				if (lastHash != transactionHash) {
					const response = await Moralis.EvmApi.transaction.getTransaction({
					    transactionHash,
					    chain,
					});
					txdatas = response.toJSON();

					if (lastHash != '') {
						lastTradingData.usd = web3.utils.fromWei(hashMap[lastHash]['USDC'], "mwei");
						// This value is for fee. Fee is 1%. 
						lastTradingData.quantity = web3.utils.fromWei((hashMap[lastHash]['HILO'] + '00'), "ether");							
						tradingData.push(lastTradingData);

						console.log(lastTradingData);
					}

					lastHash = transactionHash;
				}
				
				const wallet_address = txdatas.from_address;
				const lp_address = AddrLPToken.toLowerCase();
				const token_address = AddrHiloTokenContract.toLowerCase();

				if (hashMap[transactionHash] == null) {
					hashMap[transactionHash] = [];
					hashMap[transactionHash]['HILO'] = 0;
					hashMap[transactionHash]['USDC'] = 0;
				}
				if (new BN(hashMap[transactionHash]['HILO']) < new BN(history[i].value) && history[i].address == token_address) {
					hashMap[transactionHash]['HILO'] = history[i].value;
				} else if (new BN(hashMap[transactionHash]['USDC']) < new BN(history[i].value) && history[i].address != token_address) {
					hashMap[transactionHash]['USDC'] = history[i].value;
				}

				if (history[i].from_address == wallet_address && history[i].to_address == lp_address) {
					if (history[i].address == token_address) {
						// Sell
						lastTradingData = {
							txHash: transactionHash,
							action: "Sell",
							address: wallet_address,
							quantity: web3.utils.fromWei(history[i].value, "ether"),
							usd: 0
						};

					} else {
						// Buy
						lastTradingData = {
							txHash: transactionHash,
							action: "Buy",
							address: wallet_address,
							quantity: 0,
							usd: web3.utils.fromWei(history[i].value, "ether")
						};
					}		
				} else if (history[i].from_address == lp_address && history[i].to_address == wallet_address) {
					// Buy
					lastTradingData = {
						txHash: transactionHash,
						action: "Buy",
						address: wallet_address,
						quantity: web3.utils.fromWei(history[i].value, "ether"),
						usd: 0
					};
				}
            }
       } while (cursor != null)

       stringify(tradingData, { header: true, columns: resultTemplate }, (err, output) => {
	        if (err) throw err;
	        Fs.writeFile('./txData/tradingData.csv', output, (err) => {
	            if (err) throw err;
	            console.log('tradingData.csv saved.');
	        });
	   });
    } catch (e) {
        console.log(e);
    }
};

const runApp = async () => {
	await getTransferData();
};

runApp();