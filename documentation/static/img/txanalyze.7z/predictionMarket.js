const Web3 = require("web3");
const express = require("express");
const axios = require('axios');
const BN = require('bn.js');
const Fs = require('fs/promises');
const { stringify } = require('csv-stringify');
const { parse } = require('path');
const Moralis = require("moralis").default;
const { EvmChain } = require("@moralisweb3/common-evm-utils");

const app = express();

var provider = 'https://mainnet.infura.io/v3/8c1f6af0bba24e5287b4433e59a6fa63';
var web3Provider = new Web3.providers.HttpProvider(provider);
var web3 = new Web3(web3Provider);

const AddrUniswapRouter = "0x7a250d5630b4cf539739df2c5dacb4c659f2488d";
const AddrUniswapFactory = '0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f';
const AddrHiloTokenContract = '0xbb9FD9Fa4863C03c574007fF3370787B9cE65ff6';
const AddrPredictionMarketContract = '0x196247c168F1B94D969CF24F044C1FBa9d394B48';
const AddrLPToken = '0x659e36b0700D9addB259EbA18fA88173656ef054';
const LPTokenSymbol = 'Uniswap V2: USDC-HILO';

const DecimalHilo = 18;

const MoralisAPIKey = 'rydCaW0KZV9iA4LAErpAtJR3gsQILYFAJhEkesN9bgsKiGwhdoeFO6dhuUdDHYk8';

const ABIClaim = {"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Claim","type":"event"};
const ABIBetBear = {"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"BetBear","type":"event"};
const ABIBetBull = {"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"BetBull","type":"event"};

const topicClaim = '0x34fcbac0073d7c3d388e51312faf357774904998eeb8fca628b9e6f65ee1cbf7';
const topicBetBear = '0x0d8c1fe3e67ab767116a81f122b83c2557a8c2564019cb7c4f83de1aeb1f1f0d';
const topicBetBull = '0x438122d8cff518d18388099a5181f0d17a12b4f1b55faedf6e4a6acee0060c12';

let Data = [];
Data['claim'] = [];
Data['betBear'] = [];
Data['betBull'] = [];
Data['address'] = [];

const setData = async () => {
  await Moralis.start({
    apiKey: MoralisAPIKey,
    // ...and any other configuration
  });

  const address = AddrPredictionMarketContract;

  const chain = EvmChain.ETHEREUM;
  limit: 1000

  let response = await Moralis.EvmApi.events.getContractEvents({
    address,
    chain,
    topic: topicClaim,
    abi: ABIClaim,
    limit: 1000
  });

  Data['claim'] = response.toJSON().result;

  response = await Moralis.EvmApi.events.getContractEvents({
    address,
    chain,
    topic: topicBetBear,
    abi: ABIBetBear,
    limit: 1000
  });

  Data['betBear'] = response.toJSON().result;

  response = await Moralis.EvmApi.events.getContractEvents({
    address,
    chain,
    topic: topicBetBull,
    abi: ABIBetBull,
    limit: 1000
  });

  Data['betBull'] = response.toJSON().result;

  for (let i = 0; i < Data['claim'].length; i++) {
    if (Data['address'][Data['claim'][i].data.sender] ==  null) {
      Data['address'][Data['claim'][i].data.sender] = [];
    }
    Data['address'][Data['claim'][i].data.sender].push({
      ...Data['claim'][i],
      type: 'claim'
    });
  }

  for (i = 0; i < Data['betBull'].length; i++) {
    if (Data['address'][Data['betBull'][i].data.sender] ==  null) {
      Data['address'][Data['betBull'][i].data.sender] = [];
    }
    Data['address'][Data['betBull'][i].data.sender].push({
      ...Data['betBull'][i],
      type: 'betBull'
    });
  }

  for (let i = 0; i < Data['betBear'].length; i++) {
    if (Data['address'][Data['betBear'][i].data.sender] ==  null) {
      Data['address'][Data['betBear'][i].data.sender] = [];
    }
    Data['address'][Data['betBear'][i].data.sender].push({
      ...Data['betBear'][i],
      type: 'betBear'
    });
  }

  let addressData = [];
  for (let i in Data['address']) {
    addressData.push(Data['address'][i]);
  }
  Data['address'] = addressData;
  await Fs.writeFile(`./txData/topicData.json`, JSON.stringify({...Data}));
};

const getData = async () => {
  const json = await Fs.readFile('./txData/topicData.json');
	const data = JSON.parse(json);
  
  let leaderboardData = [];
  for (let i = 0; i < data.address.length; i++) {
    const addressData = data.address[i];
    
    let roundsInvolved = 0;
    let winningRounds = 0;
    let winningRate = 0;
    let netPayout = new BN('0');
    let totalReward = new BN('0');

    for (let j = 0; j < addressData.length; j++) {
      if (addressData[j].type == 'claim') {
        winningRounds++;
        totalReward = totalReward.add(new BN(addressData[j].data.amount));
      } else {
        roundsInvolved++;
        netPayout = netPayout.add(new BN(addressData[j].data.amount));
      }
    }

    winningRate = winningRounds * 100 / roundsInvolved;

    leaderboardData.push({
      address: addressData[0].data.sender,
      roundsInvolved,
      winningRounds,
      winningRate: winningRate.toString() + '%',
      netPayout: netPayout.toString(),
      totalReward: totalReward.toString()
    });
  }

  console.log(leaderboardData);
  
  await Fs.writeFile(`./txData/leaderboardData.json`, JSON.stringify(leaderboardData));
};

const runApp = async () => {
  await getData();
};

runApp();