### ```"A Decentralized Betting Game powered by Chainlink Randomness."```

### 🔧 Project Diagram
![Project workflow](https://i.gyazo.com/0d76efbda6fce78509eabb1f68c928da.png)
