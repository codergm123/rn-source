const dotenv = require('dotenv');
dotenv.config();
const BN = require('bn.js');
const Fs = require('fs/promises');
const Web3 = require("web3");
const connectDB = require('./config/db.js');
const Moralis = require("moralis").default;
const { EvmChain } = require("@moralisweb3/common-evm-utils");
const Events = require('./models/Events');

var provider = 'https://mainnet.infura.io/v3/8c1f6af0bba24e5287b4433e59a6fa63';
//var provider = 'https://goerli.infura.io/v3/b406202ed5624dd5a0b562f3972cbd61';
var web3Provider = new Web3.providers.HttpProvider(provider);
var web3 = new Web3(web3Provider);

const MoralisAPIKey = 'rydCaW0KZV9iA4LAErpAtJR3gsQILYFAJhEkesN9bgsKiGwhdoeFO6dhuUdDHYk8';

const AddrPredictionMarketContract = '0x196247c168F1B94D969CF24F044C1FBa9d394B48';
//const AddrPredictionMarketContract = '0xa9a1aec1b8ca47d4dc70b84791cc844149f64479';

const ABIClaim = {"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Claim","type":"event"};
const ABIBetBear = {"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"BetBear","type":"event"};
const ABIBetBull = {"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"BetBull","type":"event"};

const topicClaim = '0x34fcbac0073d7c3d388e51312faf357774904998eeb8fca628b9e6f65ee1cbf7';
const topicBetBear = '0x0d8c1fe3e67ab767116a81f122b83c2557a8c2564019cb7c4f83de1aeb1f1f0d';
const topicBetBull = '0x438122d8cff518d18388099a5181f0d17a12b4f1b55faedf6e4a6acee0060c12';

let Data = [];

const setData = async () => {

  const json = await Fs.readFile("./txData/topicData.json");
  const data = JSON.parse(json);

  for (let i = 0; i < data['claim'].length; i++) {
    Data.push({
      address: data['claim'][i].address,
      transaction_hash: data['claim'][i].transaction_hash,
      block_number: data['claim'][i].block_number,
      block_hash: data['claim'][i].block_hash,
      sender: data['claim'][i].data.sender,
      round: data['claim'][i].data.round,
      amount: data['claim'][i].data.amount,
      type: 'claim'
    });
  }
   
  for (let i = 0; i < data['betBull'].length; i++) {
    Data.push({
      address: data['betBull'][i].address,
      transaction_hash: data['betBull'][i].transaction_hash,
      block_number: data['betBull'][i].block_number,
      block_hash: data['betBull'][i].block_hash,
      sender: data['betBull'][i].data.sender,
      round: data['betBull'][i].data.round,
      amount: data['betBull'][i].data.amount,
      type: 'betBull'
    });
  }

  for (let i = 0; i < data['betBear'].length; i++) {
    Data.push({
      address: data['betBear'][i].address,
      transaction_hash: data['betBear'][i].transaction_hash,
      block_number: data['betBear'][i].block_number,
      block_hash: data['betBear'][i].block_hash,
      sender: data['betBear'][i].data.sender,
      round: data['betBear'][i].data.round,
      amount: data['betBear'][i].data.amount,
      type: 'betBear'
    });
  }

  Events.collection.insertMany(Data, (err) => {
    if (err) {
      console.log(err);
      res.status(500).send('DB Error');
      return;
    }
    console.log("================");
  });
};

const runC = async () => {
  // Connect to Database
  await connectDB();

  await setData();
}

runC();