const dotenv = require('dotenv');
dotenv.config();
const BN = require('bn.js');
const Fs = require('fs/promises');
const Web3 = require("web3");
const connectDB = require('./config/db.js');
const Moralis = require("moralis").default;
const { EvmChain } = require("@moralisweb3/common-evm-utils");
const PlayersInfo = require('./models/PlayersInfo');

var provider = 'https://mainnet.infura.io/v3/8c1f6af0bba24e5287b4433e59a6fa63';
//var provider = 'https://goerli.infura.io/v3/b406202ed5624dd5a0b562f3972cbd61';
var web3Provider = new Web3.providers.HttpProvider(provider);
var web3 = new Web3(web3Provider);

const MoralisAPIKey = 'rydCaW0KZV9iA4LAErpAtJR3gsQILYFAJhEkesN9bgsKiGwhdoeFO6dhuUdDHYk8';

const AddrPredictionMarketContract = '0x196247c168F1B94D969CF24F044C1FBa9d394B48';
//const AddrPredictionMarketContract = '0xa9a1aec1b8ca47d4dc70b84791cc844149f64479';

const ABIClaim = {"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Claim","type":"event"};
const ABIBetBear = {"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"BetBear","type":"event"};
const ABIBetBull = {"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"BetBull","type":"event"};

const topicClaim = '0x34fcbac0073d7c3d388e51312faf357774904998eeb8fca628b9e6f65ee1cbf7';
const topicBetBear = '0x0d8c1fe3e67ab767116a81f122b83c2557a8c2564019cb7c4f83de1aeb1f1f0d';
const topicBetBull = '0x438122d8cff518d18388099a5181f0d17a12b4f1b55faedf6e4a6acee0060c12';

let Data = [];
Data['claim'] = [];
Data['betBear'] = [];
Data['betBull'] = [];
Data['address'] = [];

const setData = async () => {

  const address = AddrPredictionMarketContract;

  const chain = EvmChain.ETHEREUM;
//  const chain = EvmChain.GOERLI;

  let response = await Moralis.EvmApi.events.getContractEvents({
    address,
    chain,
    topic: topicClaim,
    abi: ABIClaim,
    limit: 1000
  });

  Data['claim'] = response.toJSON().result;

  response = await Moralis.EvmApi.events.getContractEvents({
    address,
    chain,
    topic: topicBetBear,
    abi: ABIBetBear,
    limit: 1000
  });

  Data['betBear'] = response.toJSON().result;

  response = await Moralis.EvmApi.events.getContractEvents({
    address,
    chain,
    topic: topicBetBull,
    abi: ABIBetBull,
    limit: 1000
  });

  Data['betBull'] = response.toJSON().result;

  if (Data['claim'].length == 0 && Data['betBear'].length == 0 && Data['betBull'].length == 0) {
    console.log("No events found!")
    return;
  }

  await Fs.writeFile("./txData/lastTxHash.json", JSON.stringify({
    "lastTXHashClaim": (Data['claim'].length != 0) ? Data['claim'][0].transaction_hash : '',
    "lastTXHashBetBear": (Data['betBear'].length != 0) ? Data['betBear'][0].transaction_hash : '',
    "lastTXHashBetBull": (Data['betBull'].length != 0) ? Data['betBull'][0].transaction_hash : ''
  }));

  for (let i = 0; i < Data['claim'].length; i++) {
    if (Data['address'][Data['claim'][i].data.sender] ==  null) {
      Data['address'][Data['claim'][i].data.sender] = [];
    }
    Data['address'][Data['claim'][i].data.sender].push({
      ...Data['claim'][i],
      type: 'claim'
    });
  }

  for (i = 0; i < Data['betBull'].length; i++) {
    if (Data['address'][Data['betBull'][i].data.sender] ==  null) {
      Data['address'][Data['betBull'][i].data.sender] = [];
    }
    Data['address'][Data['betBull'][i].data.sender].push({
      ...Data['betBull'][i],
      type: 'betBull'
    });
  }

  for (let i = 0; i < Data['betBear'].length; i++) {
    if (Data['address'][Data['betBear'][i].data.sender] ==  null) {
      Data['address'][Data['betBear'][i].data.sender] = [];
    }
    Data['address'][Data['betBear'][i].data.sender].push({
      ...Data['betBear'][i],
      type: 'betBear'
    });
  }

  let addressData = [];
  for (let i in Data['address']) {
    addressData.push(Data['address'][i]);
  }
  Data['address'] = addressData;
  await Fs.writeFile(`./txData/topicData.json`, JSON.stringify({...Data}));
  
  let leaderboardData = [];
  for (let i = 0; i < Data.address.length; i++) {
    const addressData = Data.address[i];
    
    let roundsInvolved = 0;
    let winningRounds = 0;
    let winningRate = 0;
    let netPayout = new BN('0');
    let totalReward = new BN('0');

    for (let j = 0; j < addressData.length; j++) {
      if (addressData[j].type == 'claim') {
        winningRounds++;
        totalReward = totalReward.add(new BN(addressData[j].data.amount));
      } else {
        roundsInvolved++;
        netPayout = netPayout.add(new BN(addressData[j].data.amount));
      }
    }

    winningRate = winningRounds * 100 / roundsInvolved;

    leaderboardData.push({
      address: addressData[0].data.sender,
      roundsInvolved,
      winningRounds,
      winningRate: winningRate.toString() + '%',
      netPayout: netPayout.toString(),
      totalReward: totalReward.toString()
    });
  }

  console.log(leaderboardData);
  
  await Fs.writeFile(`./txData/leaderboardData.json`, JSON.stringify(leaderboardData));

  console.log("============Get Events Data============");

  let data = [];
  for (let i = 0; i < leaderboardData.length; i++) {
    data.push({
      ...leaderboardData[i],
      netPayoutToken: Math.round(web3.utils.fromWei(leaderboardData[i].netPayout, "ether")),
      totalRewardToken: Math.round(web3.utils.fromWei(leaderboardData[i].totalReward, "ether"))
    });
  }

  const newplayersInfo = new PlayersInfo({
    data
  });

  PlayersInfo.deleteMany({}, (err) => {
    if (err) {
      console.log(err);
    } else {
      PlayersInfo.collection.insertMany(data, (err) => {
        if (err) {
          console.log(err);
          res.status(500).send('DB Error');
          return;
        }
        Data = [];
        Data['claim'] = [];
        Data['betBear'] = [];
        Data['betBull'] = [];
        Data['address'] = [];
        console.log("================");
      });
    }
  });
};

const runC = async () => {
  // Connect to Database
  await connectDB();
  await Moralis.start({
    apiKey: MoralisAPIKey,
    // ...and any other configuration
  });
  await setData();
//  setInterval(setData, 60000);
}

runC();