const Web3 = require("web3");
const BN = require('bn.js');
const Fs = require('fs/promises');

const { ethers, JsonRpcProvider } = require("ethers");

const PlayersInfo = require("./models/PlayersInfo");
const Events = require("./models/Events");
var provider = 'https://mainnet.infura.io/v3/8c1f6af0bba24e5287b4433e59a6fa63';
//var provider = 'https://goerli.infura.io/v3/b406202ed5624dd5a0b562f3972cbd61';
var web3Provider = new Web3.providers.HttpProvider(provider);
var web3 = new Web3(web3Provider);
const connectDB = require('./config/db.js');

const AddrPredictionMarketContract = '0x196247c168F1B94D969CF24F044C1FBa9d394B48';
//const AddrPredictionMarketContract = '0xa9a1aec1b8ca47d4dc70b84791cc844149f64479';


const ABIPredictionMarket = [{"inputs":[{"internalType":"contract IERC20","name":"_token","type":"address"},{"internalType":"address","name":"_adminAddress","type":"address"},{"internalType":"address","name":"_operatorAddress","type":"address"},{"internalType":"uint256","name":"_minBetAmount","type":"uint256"},{"internalType":"uint256","name":"_treasuryFee","type":"uint256"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"BetBear","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"BetBull","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Claim","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"enum PredictionMarket.Outcome","name":"outcome","type":"uint8"}],"name":"EndRound","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"admin","type":"address"}],"name":"NewAdminAddress","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"minBetAmount","type":"uint256"}],"name":"NewMinBetAmount","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"operator","type":"address"}],"name":"NewOperatorAddress","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"treasuryFee","type":"uint256"}],"name":"NewTreasuryFee","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"}],"name":"Pause","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Paused","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"rewardBaseCalAmount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"rewardAmount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"treasuryAmount","type":"uint256"}],"name":"RewardsCalculated","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"}],"name":"StartRound","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"token","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"TokenRecovery","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"TreasuryClaim","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"round","type":"uint256"}],"name":"Unpause","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Unpaused","type":"event"},{"inputs":[],"name":"MAX_TREASURY_FEE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"adminAddress","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"epoch","type":"uint256"},{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"betBear","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"epoch","type":"uint256"},{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"betBull","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256[]","name":"epochs","type":"uint256[]"}],"name":"claim","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"claimTreasury","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"epoch","type":"uint256"},{"internalType":"address","name":"user","type":"address"}],"name":"claimable","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_epochToEnd","type":"uint256"},{"internalType":"enum PredictionMarket.Outcome","name":"_outcome","type":"uint8"}],"name":"closeRound","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"currentRound","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"user","type":"address"},{"internalType":"uint256","name":"cursor","type":"uint256"},{"internalType":"uint256","name":"size","type":"uint256"}],"name":"getUserRounds","outputs":[{"internalType":"uint256[]","name":"","type":"uint256[]"},{"components":[{"internalType":"enum PredictionMarket.Position","name":"position","type":"uint8"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"bool","name":"claimed","type":"bool"}],"internalType":"struct PredictionMarket.BetInfo[]","name":"","type":"tuple[]"},{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"user","type":"address"}],"name":"getUserRoundsLength","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"}],"name":"ledger","outputs":[{"internalType":"enum PredictionMarket.Position","name":"position","type":"uint8"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"bool","name":"claimed","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"minBetAmount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"operatorAddress","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pause","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_token","type":"address"},{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"recoverToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"rounds","outputs":[{"internalType":"uint256","name":"epoch","type":"uint256"},{"internalType":"uint256","name":"startTimestamp","type":"uint256"},{"internalType":"uint256","name":"lockTimestamp","type":"uint256"},{"internalType":"uint256","name":"closeTimestamp","type":"uint256"},{"internalType":"uint256","name":"totalAmount","type":"uint256"},{"internalType":"uint256","name":"bullAmount","type":"uint256"},{"internalType":"uint256","name":"bearAmount","type":"uint256"},{"internalType":"uint256","name":"rewardBaseCalAmount","type":"uint256"},{"internalType":"uint256","name":"rewardAmount","type":"uint256"},{"internalType":"bool","name":"roundClosed","type":"bool"},{"internalType":"enum PredictionMarket.Outcome","name":"outcome","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_adminAddress","type":"address"}],"name":"setAdmin","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_minBetAmount","type":"uint256"}],"name":"setMinBetAmount","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_operatorAddress","type":"address"}],"name":"setOperator","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_treasuryFee","type":"uint256"}],"name":"setTreasuryFee","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_lockTimestamp","type":"uint256"},{"internalType":"uint256","name":"_closeTimestamp","type":"uint256"}],"name":"startNewRound","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"token","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"treasuryAmount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"treasuryFee","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"unpause","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"uint256","name":"","type":"uint256"}],"name":"userRounds","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"}];

const iface = new ethers.Interface(ABIPredictionMarket);

const providerE = new JsonRpcProvider(provider);

const PredictionMarketContract = new ethers.Contract(
  AddrPredictionMarketContract,
  ABIPredictionMarket,
  providerE
);

const saveData = async (data) => {
  Fs.writeFile("./txData/RealTimeEvent.txt", JSON.stringify(data));
}

const updateDatabase = async (type, data) => {

  let player = await PlayersInfo.findOne({ address: data.address }).catch(err => {
    console.log(err);
  });


  if (!player) {
    player = new PlayersInfo({
      ...data       
    });
    
    player.save();

    return;
  }

  if (type == 'claim') {
    player.winningRounds++;
    player.totalReward = (new BN(player.totalReward).add(new BN(data.totalReward))).toString();
    player.totalRewardToken += data.totalRewardToken;
    player.winningRate = player.winningRounds * 100 / player.roundsInvolved + '%';
  } else {
    player.roundsInvolved++;
    player.netPayout = (new BN(player.netPayout).add(new BN(data.netPayout))).toString();
    player.netPayoutToken += data.netPayoutToken;
    player.winningRate = player.winningRounds * 100 / player.roundsInvolved + '%';
  }

  player.save();
}

const capitalizeString = (str) => {
  if (str == '' || str == null)
    return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

const generateData = (type, result) => {
  const decodedData = iface.decodeEventLog(capitalizeString(type), result.data, result.topics);

  const data = {
    transaction_hash: result.transactionHash,
    address: result.address,
    block_number: result.blockNumber,
    block_hash: result.blockHash,
    data: {
        sender: decodedData[0],
        round: (new BN(decodedData[1])).toString(),
        amount: (new BN(decodedData[2])).toString(),
    }
  };

  const events = new Events({
    address: data.address,
    transaction_hash: data.transaction_hash,
    block_number: data.block_number,
    block_hash: data.block_hash,
    sender: data.data.sender,
    round: data.data.round,
    amount: data.data.amount,
    type
  });

  events.save();

  return {
    address: data.data.sender,
    roundsInvolved: (type == 'claim') ? 0 : 1,
    winningRounds: (type == 'claim') ? 1 : 0,
    winningRate: "0%",
    netPayout: (type == 'claim') ? '0': data.data.amount,
    netPayoutToken: (type == 'claim') ? 0 : Math.round(web3.utils.fromWei(data.data.amount, "ether")),
    totalReward: (type == 'claim') ? data.data.amount : '0',
    totalRewardToken: (type == 'claim') ? Math.round(web3.utils.fromWei(data.data.amount, "ether")) : 0
  };
}

const runC = async () => {
  console.log("start listening...");
  await connectDB();

  const claimFilter = {
    address: AddrPredictionMarketContract,
    topics: [
        // the name of the event, parnetheses containing the data type of each event, no spaces
        ethers.id("Claim(address,uint256,uint256)")
    ]
  }

  const betBullFilter = {
    address: AddrPredictionMarketContract,
    topics: [
        // the name of the event, parnetheses containing the data type of each event, no spaces
        ethers.id("BetBull(address,uint256,uint256)")
    ]
  }

  const betBearFilter = {
    address: AddrPredictionMarketContract,
    topics: [
        // the name of the event, parnetheses containing the data type of each event, no spaces
        ethers.id("BetBear(address,uint256,uint256)")
    ]
  }
  
  providerE.on(claimFilter, async (result) => {
    await Fs.appendFile("claimEvents.txt", JSON.stringify(result));
    const data = await generateData('claim', result);
    await Fs.appendFile("events.txt", JSON.stringify(data));
    updateDatabase('claim', data);
  });

  providerE.on(betBullFilter, async (result) => {
    await Fs.appendFile("betBullEvents.txt", JSON.stringify(result));
    const data = await generateData('betBull', result);
    await Fs.appendFile("events.txt", JSON.stringify(data));
    updateDatabase('betBull', data);
  });

  providerE.on(betBearFilter, async (result) => {
    await Fs.appendFile("betBearEvents.txt", JSON.stringify(result));
    const data = await generateData('betBear', result);
    await Fs.appendFile("events.txt", JSON.stringify(data));
    updateDatabase('betBear', data);
  });
};

 runC();