const axios = require('axios');
const BN = require('bn.js');
const fs = require('fs');
const { stringify } = require('csv-stringify');
const { parse } = require('path');

const WALLET_ADDRESS = "0xbb9FD9Fa4863C03c574007fF3370787B9cE65ff6"

const FEED_URL = "https://api.covalenthq.com/v1/1/address/" + WALLET_ADDRESS + "/transactions_v2/?limit=10000&key=ckey_8615b3cbdebf4ff9a3b59e5785d";

const addTokenList = (address, flag) => {
    if (flag == "buy") {
        if (typeof savedSellIndex[address] == "undefined")
            allTokens.push(address);
    }
    else if (flag == "sell") {
        if (typeof savedBuyIndex[address] == "undefined")
            allTokens.push(address);
    }
}

let dataset;

async function loadWalletData() {
    const response = await axios.get(FEED_URL);
    dataset = response.data.data;
}


function tradeAnalyze() {
    console.log(dataset);
}

async function main() {
    await loadWalletData();
    tradeAnalyze();
}

main();